library(rvest)
library(dplyr)
library(stringr)
library(xml2)

fetch_from_pubmed <- function(page,n,limitsize,sleepafter10k=0,start_page="",end_page="",maxsize_db=200){
  
  n <- ifelse(!is.na(limitsize) & (limitsize<n),limitsize,n)
  
  ids <- page %>% html_nodes('id') %>% html_text()
  ids <- ids[1:n]
  
  #link <- paste('https://www.ncbi.nlm.nih.gov/pubmed/',ids,sep='')
  
  if (n <= maxsize_db) {
    print(paste('Total results: ', n, sep=''))
    url_summary <- paste('https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=',
                         paste(ids,collapse=','),
                         '&rettype=text',sep='')
    page_summary <- read_html(url_summary)
    title <- page_summary %>% html_nodes('articletitle') %>% html_text()
    
    Date_cur <- page_summary %>% html_nodes('datecompleted') %>% html_text() %>% as.numeric()
    Date_cur <- paste0(str_sub(Date_cur,1,4),'-',str_sub(Date_cur,5,6),'-',str_sub(Date_cur,7,8))
    
    article_nodes <- page_summary %>% html_nodes('pubmedarticle')
    
    nodes_remove <- article_nodes_cur %>% html_nodes("referencelist")
    xml_remove(nodes_remove)
    link_cur <- paste0('https://www.ncbi.nlm.nih.gov/pubmed/',article_nodes_cur %>% html_nodes('articleid[idtype=pubmed]') %>% html_text())
    
    author <- c()
    abstract <- c()
    keywords <- c()
    for (article_node in article_nodes) {
      author <- c(author,paste(article_node %>% html_nodes('forename') %>% html_text(),article_node %>% html_nodes('lastname') %>% html_text(),collapse = ', '))
      abstract_now <- article_node %>% html_nodes('abstract') %>% html_text()
      keywords_now <- article_node %>% html_nodes('keywordlist')
      if (length(keywords_now) > 0) {
        keywords <- c(keywords, paste(unlist(lapply(keywords_now %>% html_children(), html_text)),collapse = ', '))
      } else {
        keywords <- c(keywords, "No keywords listed")
      }
      abstract <- if(length(abstract_now)>0) c(abstract,abstract_now) else c(abstract,'No abstract')
    }
    
    print(paste("Done: ", n,'/',n,sep=''))
  } else {
    num_page = ifelse(n %% maxsize_db == 0, n %/% maxsize_db,n %/% maxsize_db + 1)
    
    print(paste('Total results: ', n, sep=''))
    print(paste('Total pages: ', num_page, sep=''))
    
    if (!is.numeric(start_page)) start_page <- 1
    if (!is.numeric(end_page)) end_page <- num_page
    count_done <- 0
    threshold <- 10000
    df_res <- data.frame()
    
    range_k = seq(start_page,end_page)
    for (k in range_k) {
      print(paste('Current page: ',k,'/', num_page, sep=''))
      
      ids_cur <- if (k < num_page) ids[seq((1+maxsize_db*(k-1)),maxsize_db*k)] else ids[seq((1+maxsize_db*(k-1)),length(ids))]
      url_summary_cur <- paste('https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=',
                               paste(ids_cur,collapse=','),
                               '&rettype=text',sep='')
      page_summary_cur <- read_html(url_summary_cur)
      article_nodes_cur <- page_summary_cur %>% html_nodes('pubmedarticle')
      
      ## remove noisy child nodes
      nodes_remove <- article_nodes_cur %>%  html_nodes('commentscorrectionslist')
      xml_remove(nodes_remove)
      nodes_remove <- article_nodes_cur %>% html_nodes("referencelist")
      xml_remove(nodes_remove)
      
      df_res_cur <- bind_rows(lapply(article_nodes_cur, 
                                     function(x) {
                                       ## get date
                                       Date_articledate <-  x %>% html_nodes('articledate') %>% html_text()
                                       Date_pubdate <- x %>% html_nodes('pubdate') %>% html_text()
                                       res <- data.frame(
                                         list(
                                           id = x %>% html_nodes('pmid') %>% html_text(), 
                                           title = x %>% html_nodes('articletitle') %>% html_text() %>% str_replace_all("|",""),
                                           Date = ifelse(length(Date_articledate) > 0, Date_articledate,
                                                         ifelse(!is.null(Date_pubdate),Date_pubdate,NA)),
                                           link = paste0('https://www.ncbi.nlm.nih.gov/pubmed/',x %>% html_nodes('articleid[idtype=pubmed]') %>% html_text()),
                                           author = paste(x %>% html_nodes('forename') %>% html_text(),
                                                          x %>% html_nodes('lastname') %>% html_text(),collapse = ', '),
                                           abstract = ifelse(length(x %>% html_nodes('abstract') %>% html_text()) > 0, x %>% html_nodes('abstract') %>% html_text() %>% str_replace_all("|",""), NA),
                                           keywords = ifelse(length(x %>% html_nodes('keywordlist')) > 0, paste(unlist(lapply(x %>% html_nodes('keywordlist') %>% html_children(), html_text)),collapse = ', '), NA)
                                         ),
                                         stringsAsFactors=FALSE)
                                       
                                       if (is.na(res$Date)){
                                         print(res)
                                         print(Date_articledate)
                                         print(Date_pubdate)
                                         print(typeof(Date_pubdate))
                                         print('----')
                                       }
                                       
                                       res
                                       
                                     }))
      
      if (length(article_nodes_cur) == nrow(df_res_cur)){
        print('Appended data check: Pass')
      } else {
        write.table(url_summary_cur,'debug url.txt')
        stop(paste0('Appended data check failed: ',
                    ', article nodes ', length(article_nodes_cur),
                    ', df_res_cur ', nrow(df_res_cur),
                    '\nCheck the debug link in *debug url.txt*'))
      }
      
      df_res <- rbind(df_res,df_res_cur)
      
      count_done <- count_done + df_res_cur %>% nrow()
      print(paste("Done: ", count_done,'/',maxsize_db*(end_page-start_page+1),sep=''))
      
      if ((count_done + maxsize_db) > threshold & sleepafter10k>0){
        threshold <- threshold + 10000
        print(paste('Start to sleep for ', sleepafter10k, ' seconds', sep=''))
        Sys.sleep(sleepafter10k)
      }
      
    }
  }
  
  return(df_res)
}